﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ToTheWorldORIGINAL.Models.dbModels
{
    [Keyless]
    public partial class Wciudade
    {
        public int IdCiudad { get; set; }
        public int IdUsuario { get; set; }
        [Required]
        [StringLength(50)]
        public string Nombre { get; set; }
        public int Estado { get; set; }
        [Required]
        public string Comentario { get; set; }
        [StringLength(50)]
        public string Recomendaciones { get; set; }
        public string Fotografía { get; set; }
        [StringLength(50)]
        public string Descripcion { get; set; }
    }
}
