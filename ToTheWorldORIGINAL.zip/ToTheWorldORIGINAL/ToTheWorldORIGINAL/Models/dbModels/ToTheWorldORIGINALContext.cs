﻿using System;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace ToTheWorldORIGINAL.Models.dbModels
{
    public partial class ToTheWorldORIGINALContext : IdentityDbContext
        {
        public ToTheWorldORIGINALContext()
        {
        }

        public ToTheWorldORIGINALContext(DbContextOptions<ToTheWorldORIGINALContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Ciudade> Ciudades { get; set; }
        public virtual DbSet<EstadoTipo> EstadoTipos { get; set; }
        public virtual DbSet<Wciudade> Wciudades { get; set; }

       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Modern_Spanish_CI_AS");

            modelBuilder.Entity<Ciudade>(entity =>
            {
                entity.HasOne(d => d.EstadoNavigation)
                    .WithMany(p => p.Ciudades)
                    .HasForeignKey(d => d.Estado)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Ciudades_EstadoTipo");
            });

            modelBuilder.Entity<Wciudade>(entity =>
            {
                entity.ToView("WCIUDADES");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
